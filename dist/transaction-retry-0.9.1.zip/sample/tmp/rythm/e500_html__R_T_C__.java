import play.templates.JavaExtensions; //line: -1
import play.utils.Utils; //line: 1
import play.Play; //line: 1
import models.*;
import controllers.*;
import play.exceptions.*;
import java.util.*;
import org.rythmengine.template.TemplateBase;
import java.io.*;

public class e500_html__R_T_C__ extends org.rythmengine.template.TagBase {

	@Override public java.lang.String __getName() {
		return "e500";
	}

	@Override protected void __setup() {
		if (__isDefVal(exception)) {exception = __get("exception",Exception.class) ;}
		if (__isDefVal(flash)) {flash = __get("flash",play.mvc.Scope.Flash.class) ;}
		if (__isDefVal(error_index)) {error_index = __get("error_index",Integer.class) ;}
		if (__isDefVal(error)) {error = __get("error",play.data.validation.Error.class) ;}
		if (__isDefVal(params)) {params = __get("params",play.mvc.Scope.Params.class) ;}
		if (__isDefVal(lang)) {lang = __get("lang",java.lang.String.class) ;}
		if (__isDefVal(messages)) {messages = __get("messages",play.i18n.Messages.class) ;}
		if (__isDefVal(error_isFirst)) {error_isFirst = __get("error_isFirst",Boolean.class) ;}
		if (__isDefVal(errors)) {errors = __get("errors",java.util.List.class) ;}
		if (__isDefVal(error_isLast)) {error_isLast = __get("error_isLast",Boolean.class) ;}
		if (__isDefVal(session)) {session = __get("session",play.mvc.Scope.Session.class) ;}
		if (__isDefVal(request)) {request = __get("request",play.mvc.Http.Request.class) ;}
		if (__isDefVal(_rythmPlugin)) {_rythmPlugin = __get("_rythmPlugin",org.rythmengine.play.RythmPlugin.class) ;}
		if (__isDefVal(_response_encoding)) {_response_encoding = __get("_response_encoding",java.lang.String.class) ;}
		if (__isDefVal(_renderArgs)) {_renderArgs = __get("_renderArgs",play.mvc.Scope.RenderArgs.class) ;}
		if (__isDefVal(_rythm)) {_rythm = __get("_rythm",org.rythmengine.RythmEngine.class) ;}
		if (__isDefVal(error_parity)) {error_parity = __get("error_parity",java.lang.String.class) ;}
		if (__isDefVal(_play)) {_play = __get("_play",play.Play.class) ;}
	}

	protected Exception exception=null; //line: 2
	protected play.mvc.Scope.Flash flash=null;
	protected int error_index=0;
	protected play.data.validation.Error error=null;
	protected play.mvc.Scope.Params params=null;
	protected java.lang.String lang=null;
	protected play.i18n.Messages messages=null;
	protected boolean error_isFirst=false;
	protected java.util.List<play.data.validation.Error> errors=null;
	protected boolean error_isLast=false;
	protected play.mvc.Scope.Session session=null;
	protected play.mvc.Http.Request request=null;
	protected org.rythmengine.play.RythmPlugin _rythmPlugin=null;
	protected java.lang.String _response_encoding=null;
	protected play.mvc.Scope.RenderArgs _renderArgs=null;
	protected org.rythmengine.RythmEngine _rythm=null;
	protected java.lang.String error_parity=null;
	protected play.Play _play=null;

	protected java.lang.String __renderArgName(int __pos) {
		int __p = 0;
		if (__p++ == __pos) return "exception";
		else if (__p++ == __pos) return "flash";
		else if (__p++ == __pos) return "error_index";
		else if (__p++ == __pos) return "error";
		else if (__p++ == __pos) return "params";
		else if (__p++ == __pos) return "lang";
		else if (__p++ == __pos) return "messages";
		else if (__p++ == __pos) return "error_isFirst";
		else if (__p++ == __pos) return "errors";
		else if (__p++ == __pos) return "error_isLast";
		else if (__p++ == __pos) return "session";
		else if (__p++ == __pos) return "request";
		else if (__p++ == __pos) return "_rythmPlugin";
		else if (__p++ == __pos) return "_response_encoding";
		else if (__p++ == __pos) return "_renderArgs";
		else if (__p++ == __pos) return "_rythm";
		else if (__p++ == __pos) return "error_parity";
		else if (__p++ == __pos) return "_play";
		throw new ArrayIndexOutOfBoundsException();
	}

	protected java.util.Map<java.lang.String, java.lang.Class> __renderArgTypeMap() {
		java.util.Map<java.lang.String, java.lang.Class> __m = new java.util.HashMap<String, Class>();
		__m.put("exception", Exception.class);
		__m.put("flash", play.mvc.Scope.Flash.class);
		__m.put("error_index", int.class);
		__m.put("error", play.data.validation.Error.class);
		__m.put("params", play.mvc.Scope.Params.class);
		__m.put("lang", java.lang.String.class);
		__m.put("messages", play.i18n.Messages.class);
		__m.put("error_isFirst", boolean.class);
		__m.put("errors", java.util.List.class);
		__m.put("errors__0", play.data.validation.Error.class);
		__m.put("error_isLast", boolean.class);
		__m.put("session", play.mvc.Scope.Session.class);
		__m.put("request", play.mvc.Http.Request.class);
		__m.put("_rythmPlugin", org.rythmengine.play.RythmPlugin.class);
		__m.put("_response_encoding", java.lang.String.class);
		__m.put("_renderArgs", play.mvc.Scope.RenderArgs.class);
		__m.put("_rythm", org.rythmengine.RythmEngine.class);
		__m.put("error_parity", java.lang.String.class);
		__m.put("_play", play.Play.class);
		return __m;
	}

	@SuppressWarnings("unchecked")
	public TemplateBase __setRenderArgs(java.util.Map<java.lang.String, java.lang.Object> __args) {
		if (null == __args) throw new NullPointerException();
		if (__args.isEmpty()) return this;
		super.__setRenderArgs(__args);
		if (__args.containsKey("exception")) this.exception = __get(__args,"exception",Exception.class);
		if (__args.containsKey("flash")) this.flash = __get(__args,"flash",play.mvc.Scope.Flash.class);
		if (__args.containsKey("error_index")) this.error_index = __get(__args,"error_index",Integer.class);
		if (__args.containsKey("error")) this.error = __get(__args,"error",play.data.validation.Error.class);
		if (__args.containsKey("params")) this.params = __get(__args,"params",play.mvc.Scope.Params.class);
		if (__args.containsKey("lang")) this.lang = __get(__args,"lang",java.lang.String.class);
		if (__args.containsKey("messages")) this.messages = __get(__args,"messages",play.i18n.Messages.class);
		if (__args.containsKey("error_isFirst")) this.error_isFirst = __get(__args,"error_isFirst",Boolean.class);
		if (__args.containsKey("errors")) this.errors = __get(__args,"errors",java.util.List.class);
		if (__args.containsKey("error_isLast")) this.error_isLast = __get(__args,"error_isLast",Boolean.class);
		if (__args.containsKey("session")) this.session = __get(__args,"session",play.mvc.Scope.Session.class);
		if (__args.containsKey("request")) this.request = __get(__args,"request",play.mvc.Http.Request.class);
		if (__args.containsKey("_rythmPlugin")) this._rythmPlugin = __get(__args,"_rythmPlugin",org.rythmengine.play.RythmPlugin.class);
		if (__args.containsKey("_response_encoding")) this._response_encoding = __get(__args,"_response_encoding",java.lang.String.class);
		if (__args.containsKey("_renderArgs")) this._renderArgs = __get(__args,"_renderArgs",play.mvc.Scope.RenderArgs.class);
		if (__args.containsKey("_rythm")) this._rythm = __get(__args,"_rythm",org.rythmengine.RythmEngine.class);
		if (__args.containsKey("error_parity")) this.error_parity = __get(__args,"error_parity",java.lang.String.class);
		if (__args.containsKey("_play")) this._play = __get(__args,"_play",play.Play.class);
		return this;
	}

	@SuppressWarnings("unchecked") public TemplateBase __setRenderArgs(java.lang.Object... __args) {
		int __p = 0, __l = __args.length;
		if (__p < __l) { 
			Object v = __args[__p++]; 
			exception = __safeCast(v, Exception.class); 
			__renderArgs.put("exception",exception);
		}
		return this;
	}

	protected java.lang.Class[] __renderArgTypeArray() {
		return new java.lang.Class[]{Exception.class, };
	}

	@SuppressWarnings("unchecked") @Override public TemplateBase __setRenderArg(java.lang.String __name, java.lang.Object __arg) {
		if ("exception".equals(__name)) this.exception = __safeCast(__arg, Exception.class);
		else if ("flash".equals(__name)) this.flash = __safeCast(__arg, play.mvc.Scope.Flash.class);
		else if ("error_index".equals(__name)) this.error_index = __safeCast(__arg, Integer.class);
		else if ("error".equals(__name)) this.error = __safeCast(__arg, play.data.validation.Error.class);
		else if ("params".equals(__name)) this.params = __safeCast(__arg, play.mvc.Scope.Params.class);
		else if ("lang".equals(__name)) this.lang = __safeCast(__arg, java.lang.String.class);
		else if ("messages".equals(__name)) this.messages = __safeCast(__arg, play.i18n.Messages.class);
		else if ("error_isFirst".equals(__name)) this.error_isFirst = __safeCast(__arg, Boolean.class);
		else if ("errors".equals(__name)) this.errors = __safeCast(__arg, java.util.List.class);
		else if ("error_isLast".equals(__name)) this.error_isLast = __safeCast(__arg, Boolean.class);
		else if ("session".equals(__name)) this.session = __safeCast(__arg, play.mvc.Scope.Session.class);
		else if ("request".equals(__name)) this.request = __safeCast(__arg, play.mvc.Http.Request.class);
		else if ("_rythmPlugin".equals(__name)) this._rythmPlugin = __safeCast(__arg, org.rythmengine.play.RythmPlugin.class);
		else if ("_response_encoding".equals(__name)) this._response_encoding = __safeCast(__arg, java.lang.String.class);
		else if ("_renderArgs".equals(__name)) this._renderArgs = __safeCast(__arg, play.mvc.Scope.RenderArgs.class);
		else if ("_rythm".equals(__name)) this._rythm = __safeCast(__arg, org.rythmengine.RythmEngine.class);
		else if ("error_parity".equals(__name)) this.error_parity = __safeCast(__arg, java.lang.String.class);
		else if ("_play".equals(__name)) this._play = __safeCast(__arg, play.Play.class);
		super.__setRenderArg(__name, __arg);
		return this;
	}

	@SuppressWarnings("unchecked") public TemplateBase __setRenderArg(int __pos, java.lang.Object __arg) {
		int __p = 0;
				if (__p++ == __pos) { 
			Object v = __arg; 
			exception = __safeCast(v, Exception.class); 
			__renderArgs.put("exception", exception);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			flash = __safeCast(v, play.mvc.Scope.Flash.class); 
			__renderArgs.put("flash", flash);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_index = __safeCast(v, Integer.class); 
			__renderArgs.put("error_index", error_index);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error = __safeCast(v, play.data.validation.Error.class); 
			__renderArgs.put("error", error);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			params = __safeCast(v, play.mvc.Scope.Params.class); 
			__renderArgs.put("params", params);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			lang = __safeCast(v, java.lang.String.class); 
			__renderArgs.put("lang", lang);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			messages = __safeCast(v, play.i18n.Messages.class); 
			__renderArgs.put("messages", messages);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_isFirst = __safeCast(v, Boolean.class); 
			__renderArgs.put("error_isFirst", error_isFirst);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			errors = __safeCast(v, java.util.List.class); 
			__renderArgs.put("errors", errors);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_isLast = __safeCast(v, Boolean.class); 
			__renderArgs.put("error_isLast", error_isLast);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			session = __safeCast(v, play.mvc.Scope.Session.class); 
			__renderArgs.put("session", session);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			request = __safeCast(v, play.mvc.Http.Request.class); 
			__renderArgs.put("request", request);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_rythmPlugin = __safeCast(v, org.rythmengine.play.RythmPlugin.class); 
			__renderArgs.put("_rythmPlugin", _rythmPlugin);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_response_encoding = __safeCast(v, java.lang.String.class); 
			__renderArgs.put("_response_encoding", _response_encoding);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_renderArgs = __safeCast(v, play.mvc.Scope.RenderArgs.class); 
			__renderArgs.put("_renderArgs", _renderArgs);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_rythm = __safeCast(v, org.rythmengine.RythmEngine.class); 
			__renderArgs.put("_rythm", _rythm);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_parity = __safeCast(v, java.lang.String.class); 
			__renderArgs.put("error_parity", error_parity);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_play = __safeCast(v, play.Play.class); 
			__renderArgs.put("_play", _play);
		}
		if(0 == __pos) __setRenderArg("arg", __arg);
		return this;
	}



	@Override public org.rythmengine.utils.TextBuilder build(){
		buffer().ensureCapacity(5399);
p("<style type=\"text/css\">");__ctx.pushCodeType((org.rythmengine.extension.ICodeType)org.rythmengine.extension.ICodeType.DefImpl.CSS.clone()); //line: 3
p("\n    html, body, pre {\n        margin: 0;\n        padding: 0;\n        font-family: Monaco, 'Lucida Console';\n        background: #ECECEC;\n    }\n    h1 {\n        margin: 0;\n        background: #A31012;\n        padding: 20px 45px;\n        color: #fff;\n        text-shadow: 1px 1px 1px rgba(0,0,0,.3);\n        border-bottom: 1px solid #690000;\n        font-size: 28px;\n    }\n    p#detail {\n        margin: 0;\n        padding: 15px 45px;\n        background: #F5A0A0;\n        border-top: 4px solid #D36D6D;\n        color: #730000;\n        text-shadow: 1px 1px 1px rgba(255,255,255,.3);\n        font-size: 14px;\n        border-bottom: 1px solid #BA7A7A;\n    }\n    p#detail input {\n        background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#AE1113), to(#A31012));\n        border: 1px solid #790000;\n        padding: 3px 10px;\n        text-shadow: 1px 1px 0 rgba(0, 0, 0, .5);\n        color: white;\n        border-radius: 3px;\n        cursor: pointer;\n        font-family: Monaco, 'Lucida Console';\n        font-size: 12px;\n        margin: 0 10px;\n        display: inline-block;\n        position: relative;\n        top: -1px;\n    }\n    h2 {\n        margin: 0;\n        padding: 5px 45px;\n        font-size: 12px;\n        background: #333;\n        color: #fff;\n        text-shadow: 1px 1px 1px rgba(0,0,0,.3);\n        border-top: 4px solid #2a2a2a;\n    }\n    pre {\n        margin: 0;\n        border-bottom: 1px solid #DDD;\n        text-shadow: 1px 1px 1px rgba(255,255,255,.5);\n        position: relative;\n        font-size: 12px;\n        overflow: hidden;\n    }\n    pre span.line {\n        text-align: right;\n        display: inline-block;\n        padding: 5px 5px;\n        width: 30px;\n        background: #D6D6D6;\n        color: #8B8B8B;\n        text-shadow: 1px 1px 1px rgba(255,255,255,.5);\n        font-weight: bold;\n    }\n    pre span.code {\n        padding: 5px 5px;\n        position: absolute;\n        right: 0;\n        left: 40px;\n    }\n    pre:first-child span.code {\n        border-top: 4px solid #CDCDCD;\n    }\n    pre:first-child span.line {\n        border-top: 4px solid #B6B6B6;\n    }\n    pre.error span.line {\n        background: #A31012;\n        color: #fff;\n        text-shadow: 1px 1px 1px rgba(0,0,0,.3);\n    }\n    pre.error span.code {\n        font-weight: bold;\n    }\n    pre.error {\n        color: #A31012;\n    }\n    pre.error span.marker {\n        background: #A31012;\n        color: #fff;\n        text-shadow: 1px 1px 1px rgba(0,0,0,.3);\n    }\n    #more {\n        padding: 8px;\n        font-size: 12px;\n    }\n    pre.error:hover {\n        cursor: pointer;\n    }\n    pre.error:hover span.code {\n        background-color: #D38989;\n    }\n"); //line: 109
p("</style>");__ctx.popCodeType(); //line: 109
p("\n\n"); //line: 112

if (org.rythmengine.utils.Eval.eval(exception instanceof play.exceptions.PlayException)) { //line: 111
final PlayException pex = (PlayException)exception //line: 113
; //line: 112
p("\n    <h1>"); //line: 113

try{pe(pex.getErrorTitle());} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 113
p("</h1>\n"); //line: 115

if (org.rythmengine.utils.Eval.eval("DEV".equals(Play.mode.name()))) { //line: 114
p("        <p id=\"detail\">"); //line: 115

try{pe(org.rythmengine.utils.S.raw(pex.getErrorDescription()));} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 115
p("</p>"); //line: 115

} else if (org.rythmengine.utils.Eval.eval(("PROD".equals(Play.mode.name())))) { //line: 116
p("        <p>Error details are not displayed when Play! is in PROD mode. Check server logs for detail.</p>"); //line: 117
} //line: 118
p("\n\n"); //line: 121

if (org.rythmengine.utils.Eval.eval(pex.isSourceAvailable() && (null != pex.getLineNumber()) && "DEV".equals(Play.mode.name()))) { //line: 120
 //line: 122
        String src = pex.getSourceFile(); //line: 123
        int errLineNo = pex.getLineNumber(); //line: 124
     //line: 125
 //line: 124
p("\n    <h2>In "); //line: 125

try{pe(src);} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 125
p(" (around line "); //line: 125

try{pe(errLineNo);} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 125
p(")</h2>\n    <div>"); //line: 126
 //line: 129
        final List<String> source = (pex instanceof CacheException) ? ((CacheException)pex).getSource() : ((SourceAttachment)pex).getSource(); //line: 130
        int lineNumber = (pex instanceof CacheException) ? ((CacheException)pex).getLineNumber() : ((SourceAttachment)pex).getLineNumber(); //line: 131
        final int from = lineNumber - 5 >= 0 && lineNumber < source.size() ? lineNumber - 5 : 0; //line: 132
        final int to = lineNumber + 5  < source.size() ? lineNumber + 5 : source.size()-1; //line: 133
        final List<String> lines = new ArrayList(); //line: 134
        for (int i = from; i <= to; ++i) { //line: 135
            lines.add(source.get(i)); //line: 136
        } //line: 137
     //line: 138
; //line: 137
p("\n"); //line: 139
{
__Itr<String> __v0 = __Itr.valueOf(lines); //line: 138
int line_size = __v0.size(); //line: 138
if (line_size > 0) { //line: 138
int line_index = 0; //line: 138
for(String line : __v0) { //line: 138
line_index++; //line: 138
boolean line_isOdd = line_index % 2 == 1; //line: 138
java.lang.String line_parity = line_isOdd ? "odd" : "even"; //line: 138
boolean line_isFirst = line_index == 1; //line: 138
boolean line_isLast = line_index >= line_size; //line: 138
org.rythmengine.utils.RawData line_sep = new org.rythmengine.utils.RawData(line_isLast ? "" : ","); //line: 138
org.rythmengine.utils.RawData line__sep = new org.rythmengine.utils.RawData(org.rythmengine.utils.S.escape(line)+(line_isLast ? "" : ",")); //line: 138
org.rythmengine.internal.LoopUtil line_utils = new org.rythmengine.internal.LoopUtil(line_isFirst, line_isLast); //line: 138
org.rythmengine.internal.LoopUtil line__utils = new org.rythmengine.internal.LoopUtil(line_isFirst, line_isLast, line); //line: 138
__pushItrVar("line", line); //line: 138
p("\n        <pre "); //line: 140

if (org.rythmengine.utils.Eval.eval(pex.getLineNumber() == line_index+from)) { //line: 140
p("class=\"error\" data-src=\""); //line: 140

try{pe(src);} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 140
p("\" data-line=\""); //line: 140

try{pe(errLineNo);} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 140
p("\""); //line: 140
} //line: 140
p("><span class=\"line\">"); //line: 140

try{pe((line_index+from));} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 140
p("</span><span class=\"code\">&nbsp;"); //line: 140

try{pe(org.rythmengine.utils.S.raw(org.rythmengine.utils.S.escapeXml(line).toString().replace("&darr;", "<strong>&darr;</strong>").replace("\000", "<em>").replace("\001", "</em>")));} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 140
p("</span></pre>\n"); //line: 140

	__popItrVar();
	}
}
}
 //line: 141
p("    </div>"); //line: 142
} //line: 143
p("\n"); //line: 144
 String moreHtml = pex.getMoreHTML()  //line: 146
; //line: 145
p("\n"); //line: 147

if (org.rythmengine.utils.Eval.eval(null != moreHtml)) { //line: 146
p("		<div id=\"specific\" class=\"block\">\n                        "); //line: 148

try{pe(org.rythmengine.utils.S.raw(moreHtml));} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 148
p("\n		</div>"); //line: 149
} //line: 150
p("\n    <div id=\"more\" class=\"block\">\n        This pex has been logged with id <strong>"); //line: 152

try{pe(pex.getId());} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 152
p("</strong>\n    </div>"); //line: 153
}else {
 //line: 154
p("    <div id=\"header\" class=\"block\">\n        <h1>"); //line: 156

try{pe((null == exception.getMessage() ? "" : exception.getMessage()));} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 156
p("</h1>\n    </div>"); //line: 157
} //line: 158
p("\n"); //line: 160

if (org.rythmengine.utils.Eval.eval(_rythmPlugin.enableCodeMarker)) { //line: 159
p("<script type=\"text/javascript\">");__ctx.pushCodeType((org.rythmengine.extension.ICodeType)org.rythmengine.extension.ICodeType.DefImpl.JS.clone()); //line: 160
p("\n    $('body').on('click', 'pre.error', function(){\n        var $me = $(this), src = $me.data('src'), line = $me.data('line');\n        $.get('http://localhost:8091?message='+src+\":\"+line);\n    })\n"); //line: 165
p("</script>");__ctx.popCodeType(); //line: 165
} //line: 166
p("\n"); //line: 167

		return this;
	}


	protected <T> T _getBeanProperty(Object o, String prop) {
		return (T)org.rythmengine.play.utils.JavaHelper.getProperty(o, prop);
	}

	protected void _setBeanProperty(Object o, String prop, Object val) {
		org.rythmengine.play.utils.JavaHelper.setProperty(o, prop, val);
	}

	protected boolean _hasBeanProperty(Object o, String prop) {
		return org.rythmengine.play.utils.JavaHelper.hasProperty(o, prop);
	}

    protected String _msg(String key, Object ... params) {return play.i18n.Messages.get(key, params);}
    protected play.mvc.Router.ActionDefinition _act(String action, Object... params) {return _act(false, action, params);}
    protected play.mvc.Router.ActionDefinition _act(boolean isAbsolute, String action, Object... params) {
        org.rythmengine.internal.compiler.TemplateClass tc = __getTemplateClass(true);
        boolean escapeXML = (!tc.isStringTemplate() && tc.templateResource.getKey().toString().endsWith(".xml"));
        return new org.rythmengine.play.utils.ActionBridge(isAbsolute, escapeXML).invokeMethod(action, params);
   }

    protected String _url(String action, Object... params) {return _url(false, action, params);}
    protected String _url(boolean isAbsolute, String action, Object... params) { return _act(isAbsolute, action, params).toString();
   }


}
