import play.templates.JavaExtensions; //line: -1
import models.*;
import controllers.*;
import java.util.*;
import org.rythmengine.template.TemplateBase;
import java.io.*;

public class errors_404_html__R_T_C__ extends org.rythmengine.template.TagBase {

	@Override public java.lang.String __getName() {
		return "errors.404";
	}

	@Override protected void __setup() {
		if (__isDefVal(result)) {result = __get("result",Exception.class) ;}
		if (__isDefVal(flash)) {flash = __get("flash",play.mvc.Scope.Flash.class) ;}
		if (__isDefVal(error_index)) {error_index = __get("error_index",Integer.class) ;}
		if (__isDefVal(error)) {error = __get("error",play.data.validation.Error.class) ;}
		if (__isDefVal(params)) {params = __get("params",play.mvc.Scope.Params.class) ;}
		if (__isDefVal(lang)) {lang = __get("lang",java.lang.String.class) ;}
		if (__isDefVal(messages)) {messages = __get("messages",play.i18n.Messages.class) ;}
		if (__isDefVal(error_isFirst)) {error_isFirst = __get("error_isFirst",Boolean.class) ;}
		if (__isDefVal(errors)) {errors = __get("errors",java.util.List.class) ;}
		if (__isDefVal(error_isLast)) {error_isLast = __get("error_isLast",Boolean.class) ;}
		if (__isDefVal(session)) {session = __get("session",play.mvc.Scope.Session.class) ;}
		if (__isDefVal(request)) {request = __get("request",play.mvc.Http.Request.class) ;}
		if (__isDefVal(_rythmPlugin)) {_rythmPlugin = __get("_rythmPlugin",org.rythmengine.play.RythmPlugin.class) ;}
		if (__isDefVal(_response_encoding)) {_response_encoding = __get("_response_encoding",java.lang.String.class) ;}
		if (__isDefVal(_renderArgs)) {_renderArgs = __get("_renderArgs",play.mvc.Scope.RenderArgs.class) ;}
		if (__isDefVal(_rythm)) {_rythm = __get("_rythm",org.rythmengine.RythmEngine.class) ;}
		if (__isDefVal(error_parity)) {error_parity = __get("error_parity",java.lang.String.class) ;}
		if (__isDefVal(_play)) {_play = __get("_play",play.Play.class) ;}
	}

	protected Exception result=null; //line: 1
	protected play.mvc.Scope.Flash flash=null;
	protected int error_index=0;
	protected play.data.validation.Error error=null;
	protected play.mvc.Scope.Params params=null;
	protected java.lang.String lang=null;
	protected play.i18n.Messages messages=null;
	protected boolean error_isFirst=false;
	protected java.util.List<play.data.validation.Error> errors=null;
	protected boolean error_isLast=false;
	protected play.mvc.Scope.Session session=null;
	protected play.mvc.Http.Request request=null;
	protected org.rythmengine.play.RythmPlugin _rythmPlugin=null;
	protected java.lang.String _response_encoding=null;
	protected play.mvc.Scope.RenderArgs _renderArgs=null;
	protected org.rythmengine.RythmEngine _rythm=null;
	protected java.lang.String error_parity=null;
	protected play.Play _play=null;

	protected java.lang.String __renderArgName(int __pos) {
		int __p = 0;
		if (__p++ == __pos) return "result";
		else if (__p++ == __pos) return "flash";
		else if (__p++ == __pos) return "error_index";
		else if (__p++ == __pos) return "error";
		else if (__p++ == __pos) return "params";
		else if (__p++ == __pos) return "lang";
		else if (__p++ == __pos) return "messages";
		else if (__p++ == __pos) return "error_isFirst";
		else if (__p++ == __pos) return "errors";
		else if (__p++ == __pos) return "error_isLast";
		else if (__p++ == __pos) return "session";
		else if (__p++ == __pos) return "request";
		else if (__p++ == __pos) return "_rythmPlugin";
		else if (__p++ == __pos) return "_response_encoding";
		else if (__p++ == __pos) return "_renderArgs";
		else if (__p++ == __pos) return "_rythm";
		else if (__p++ == __pos) return "error_parity";
		else if (__p++ == __pos) return "_play";
		throw new ArrayIndexOutOfBoundsException();
	}

	protected java.util.Map<java.lang.String, java.lang.Class> __renderArgTypeMap() {
		java.util.Map<java.lang.String, java.lang.Class> __m = new java.util.HashMap<String, Class>();
		__m.put("result", Exception.class);
		__m.put("flash", play.mvc.Scope.Flash.class);
		__m.put("error_index", int.class);
		__m.put("error", play.data.validation.Error.class);
		__m.put("params", play.mvc.Scope.Params.class);
		__m.put("lang", java.lang.String.class);
		__m.put("messages", play.i18n.Messages.class);
		__m.put("error_isFirst", boolean.class);
		__m.put("errors", java.util.List.class);
		__m.put("errors__0", play.data.validation.Error.class);
		__m.put("error_isLast", boolean.class);
		__m.put("session", play.mvc.Scope.Session.class);
		__m.put("request", play.mvc.Http.Request.class);
		__m.put("_rythmPlugin", org.rythmengine.play.RythmPlugin.class);
		__m.put("_response_encoding", java.lang.String.class);
		__m.put("_renderArgs", play.mvc.Scope.RenderArgs.class);
		__m.put("_rythm", org.rythmengine.RythmEngine.class);
		__m.put("error_parity", java.lang.String.class);
		__m.put("_play", play.Play.class);
		return __m;
	}

	@SuppressWarnings("unchecked")
	public TemplateBase __setRenderArgs(java.util.Map<java.lang.String, java.lang.Object> __args) {
		if (null == __args) throw new NullPointerException();
		if (__args.isEmpty()) return this;
		super.__setRenderArgs(__args);
		if (__args.containsKey("result")) this.result = __get(__args,"result",Exception.class);
		if (__args.containsKey("flash")) this.flash = __get(__args,"flash",play.mvc.Scope.Flash.class);
		if (__args.containsKey("error_index")) this.error_index = __get(__args,"error_index",Integer.class);
		if (__args.containsKey("error")) this.error = __get(__args,"error",play.data.validation.Error.class);
		if (__args.containsKey("params")) this.params = __get(__args,"params",play.mvc.Scope.Params.class);
		if (__args.containsKey("lang")) this.lang = __get(__args,"lang",java.lang.String.class);
		if (__args.containsKey("messages")) this.messages = __get(__args,"messages",play.i18n.Messages.class);
		if (__args.containsKey("error_isFirst")) this.error_isFirst = __get(__args,"error_isFirst",Boolean.class);
		if (__args.containsKey("errors")) this.errors = __get(__args,"errors",java.util.List.class);
		if (__args.containsKey("error_isLast")) this.error_isLast = __get(__args,"error_isLast",Boolean.class);
		if (__args.containsKey("session")) this.session = __get(__args,"session",play.mvc.Scope.Session.class);
		if (__args.containsKey("request")) this.request = __get(__args,"request",play.mvc.Http.Request.class);
		if (__args.containsKey("_rythmPlugin")) this._rythmPlugin = __get(__args,"_rythmPlugin",org.rythmengine.play.RythmPlugin.class);
		if (__args.containsKey("_response_encoding")) this._response_encoding = __get(__args,"_response_encoding",java.lang.String.class);
		if (__args.containsKey("_renderArgs")) this._renderArgs = __get(__args,"_renderArgs",play.mvc.Scope.RenderArgs.class);
		if (__args.containsKey("_rythm")) this._rythm = __get(__args,"_rythm",org.rythmengine.RythmEngine.class);
		if (__args.containsKey("error_parity")) this.error_parity = __get(__args,"error_parity",java.lang.String.class);
		if (__args.containsKey("_play")) this._play = __get(__args,"_play",play.Play.class);
		return this;
	}

	@SuppressWarnings("unchecked") public TemplateBase __setRenderArgs(java.lang.Object... __args) {
		int __p = 0, __l = __args.length;
		if (__p < __l) { 
			Object v = __args[__p++]; 
			result = __safeCast(v, Exception.class); 
			__renderArgs.put("result",result);
		}
		return this;
	}

	protected java.lang.Class[] __renderArgTypeArray() {
		return new java.lang.Class[]{Exception.class, };
	}

	@SuppressWarnings("unchecked") @Override public TemplateBase __setRenderArg(java.lang.String __name, java.lang.Object __arg) {
		if ("result".equals(__name)) this.result = __safeCast(__arg, Exception.class);
		else if ("flash".equals(__name)) this.flash = __safeCast(__arg, play.mvc.Scope.Flash.class);
		else if ("error_index".equals(__name)) this.error_index = __safeCast(__arg, Integer.class);
		else if ("error".equals(__name)) this.error = __safeCast(__arg, play.data.validation.Error.class);
		else if ("params".equals(__name)) this.params = __safeCast(__arg, play.mvc.Scope.Params.class);
		else if ("lang".equals(__name)) this.lang = __safeCast(__arg, java.lang.String.class);
		else if ("messages".equals(__name)) this.messages = __safeCast(__arg, play.i18n.Messages.class);
		else if ("error_isFirst".equals(__name)) this.error_isFirst = __safeCast(__arg, Boolean.class);
		else if ("errors".equals(__name)) this.errors = __safeCast(__arg, java.util.List.class);
		else if ("error_isLast".equals(__name)) this.error_isLast = __safeCast(__arg, Boolean.class);
		else if ("session".equals(__name)) this.session = __safeCast(__arg, play.mvc.Scope.Session.class);
		else if ("request".equals(__name)) this.request = __safeCast(__arg, play.mvc.Http.Request.class);
		else if ("_rythmPlugin".equals(__name)) this._rythmPlugin = __safeCast(__arg, org.rythmengine.play.RythmPlugin.class);
		else if ("_response_encoding".equals(__name)) this._response_encoding = __safeCast(__arg, java.lang.String.class);
		else if ("_renderArgs".equals(__name)) this._renderArgs = __safeCast(__arg, play.mvc.Scope.RenderArgs.class);
		else if ("_rythm".equals(__name)) this._rythm = __safeCast(__arg, org.rythmengine.RythmEngine.class);
		else if ("error_parity".equals(__name)) this.error_parity = __safeCast(__arg, java.lang.String.class);
		else if ("_play".equals(__name)) this._play = __safeCast(__arg, play.Play.class);
		super.__setRenderArg(__name, __arg);
		return this;
	}

	@SuppressWarnings("unchecked") public TemplateBase __setRenderArg(int __pos, java.lang.Object __arg) {
		int __p = 0;
				if (__p++ == __pos) { 
			Object v = __arg; 
			result = __safeCast(v, Exception.class); 
			__renderArgs.put("result", result);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			flash = __safeCast(v, play.mvc.Scope.Flash.class); 
			__renderArgs.put("flash", flash);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_index = __safeCast(v, Integer.class); 
			__renderArgs.put("error_index", error_index);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error = __safeCast(v, play.data.validation.Error.class); 
			__renderArgs.put("error", error);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			params = __safeCast(v, play.mvc.Scope.Params.class); 
			__renderArgs.put("params", params);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			lang = __safeCast(v, java.lang.String.class); 
			__renderArgs.put("lang", lang);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			messages = __safeCast(v, play.i18n.Messages.class); 
			__renderArgs.put("messages", messages);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_isFirst = __safeCast(v, Boolean.class); 
			__renderArgs.put("error_isFirst", error_isFirst);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			errors = __safeCast(v, java.util.List.class); 
			__renderArgs.put("errors", errors);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_isLast = __safeCast(v, Boolean.class); 
			__renderArgs.put("error_isLast", error_isLast);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			session = __safeCast(v, play.mvc.Scope.Session.class); 
			__renderArgs.put("session", session);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			request = __safeCast(v, play.mvc.Http.Request.class); 
			__renderArgs.put("request", request);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_rythmPlugin = __safeCast(v, org.rythmengine.play.RythmPlugin.class); 
			__renderArgs.put("_rythmPlugin", _rythmPlugin);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_response_encoding = __safeCast(v, java.lang.String.class); 
			__renderArgs.put("_response_encoding", _response_encoding);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_renderArgs = __safeCast(v, play.mvc.Scope.RenderArgs.class); 
			__renderArgs.put("_renderArgs", _renderArgs);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_rythm = __safeCast(v, org.rythmengine.RythmEngine.class); 
			__renderArgs.put("_rythm", _rythm);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			error_parity = __safeCast(v, java.lang.String.class); 
			__renderArgs.put("error_parity", error_parity);
		}
		else 		if (__p++ == __pos) { 
			Object v = __arg; 
			_play = __safeCast(v, play.Play.class); 
			__renderArgs.put("_play", _play);
		}
		if(0 == __pos) __setRenderArg("arg", __arg);
		return this;
	}



	@Override public org.rythmengine.utils.TextBuilder build(){
		buffer().ensureCapacity(478);
p("<!DOCTYPE html>\n\n<html>\n    <head>\n        <title>Not found</title>\n        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=${_response_encoding}\"/>    \n    </head>\n    <body>"); //line: 9
 //line: 11
			boolean debug = true ; //line: 12
		 //line: 13
 //line: 12
p("\n"); //line: 14

if (org.rythmengine.utils.Eval.eval("DEV".equals(_play.mode.name()) || debug )) { //line: 13
p("           "); //line: 14
{ //line: 14
	org.rythmengine.template.ITag.__ParameterList _pl = null;  //line: 14
	_pl = new org.rythmengine.template.ITag.__ParameterList(); //line: 14
	_pl.add("",result); //line: 14
		__invokeTag(14, "e404", _pl, false); //line: 14
} //line: 14
}else {
 //line: 15
p("            <h1>Not found</h1>\n            <p>\n                "); //line: 18

try{pe(result.getMessage());} catch (RuntimeException e) {__handleTemplateExecutionException(e);}  //line: 18
p("\n            </p>"); //line: 19
} //line: 20
p("\n    </body>\n</html>\n"); //line: 23

		return this;
	}


	protected <T> T _getBeanProperty(Object o, String prop) {
		return (T)org.rythmengine.play.utils.JavaHelper.getProperty(o, prop);
	}

	protected void _setBeanProperty(Object o, String prop, Object val) {
		org.rythmengine.play.utils.JavaHelper.setProperty(o, prop, val);
	}

	protected boolean _hasBeanProperty(Object o, String prop) {
		return org.rythmengine.play.utils.JavaHelper.hasProperty(o, prop);
	}

    protected String _msg(String key, Object ... params) {return play.i18n.Messages.get(key, params);}
    protected play.mvc.Router.ActionDefinition _act(String action, Object... params) {return _act(false, action, params);}
    protected play.mvc.Router.ActionDefinition _act(boolean isAbsolute, String action, Object... params) {
        org.rythmengine.internal.compiler.TemplateClass tc = __getTemplateClass(true);
        boolean escapeXML = (!tc.isStringTemplate() && tc.templateResource.getKey().toString().endsWith(".xml"));
        return new org.rythmengine.play.utils.ActionBridge(isAbsolute, escapeXML).invokeMethod(action, params);
   }

    protected String _url(String action, Object... params) {return _url(false, action, params);}
    protected String _url(boolean isAbsolute, String action, Object... params) { return _act(isAbsolute, action, params).toString();
   }


}
