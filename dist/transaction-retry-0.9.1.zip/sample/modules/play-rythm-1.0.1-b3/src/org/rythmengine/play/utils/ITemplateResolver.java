package org.rythmengine.play.utils;

/**
 * Created with IntelliJ IDEA.
 * User: luog
 * Date: 26/08/12
 * Time: 6:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ITemplateResolver {

}
