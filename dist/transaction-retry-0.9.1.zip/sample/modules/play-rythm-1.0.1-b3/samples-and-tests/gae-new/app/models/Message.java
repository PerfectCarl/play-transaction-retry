package models;

public class Message {

	public String country = "key";

	public String capital = "value";

	public Message(String country, String capital) {
		super();
		this.country = country;
		this.capital = capital;
	}
}
