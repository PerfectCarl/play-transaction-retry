package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

import org.rythmengine.*;
import org.rythmengine.play.*;

public class Application extends Controller {

    public static void index() {
        render();
    }
	
}