play-transaction-retry
======================

Play1 module to automatically retry if a transaction fails

How to use
==========

Add the following to your `dependencies.yml`

```
```

Configuration
=============


How to build
============

```
 play deps
 play build-module
```
